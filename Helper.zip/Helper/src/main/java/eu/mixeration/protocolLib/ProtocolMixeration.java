package eu.mixeration.protocolLib;

import com.comphenix.protocol.ProtocolLib;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;

public class ProtocolMixeration {

    public static ProtocolLib protocolLib;
    public static ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();

}
