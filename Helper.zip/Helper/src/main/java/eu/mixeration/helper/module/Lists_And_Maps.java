package eu.mixeration.helper.module;

import java.util.HashMap;
import java.util.UUID;

public class Lists_And_Maps {

    public static HashMap<UUID, String> notify_client = new HashMap();
    public static HashMap<UUID, String> notify_antibookcrash = new HashMap();

    public static HashMap<UUID, Long> cooldown = new HashMap();
    public static HashMap<String, Boolean> maintenance = new HashMap<String, Boolean>();
    public static HashMap<String, String> codes = new HashMap<String,String>();
    public static HashMap<String, Integer> __antiforceop = new HashMap<String,Integer>();
    public static HashMap<UUID,String> __antiFastVersionChange = new HashMap<UUID,String>();
    public static HashMap<UUID, Boolean> __antiFastVersionChange$0 = new HashMap<UUID,Boolean>();
    public static HashMap<UUID, String> __antiFastVersionChange$1 = new HashMap<UUID,String>();

}
